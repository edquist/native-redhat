"common" is shared by all skins. It is not a "skin".

"leather-dev" and "corium" are part of the new "views" plugin
under development.

The remainder are skins that you can use.
See http://forrest.apache.org/docs/skins.html
