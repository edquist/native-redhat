Note that these forrestbot descriptors are all old
and are not being used anyway.
